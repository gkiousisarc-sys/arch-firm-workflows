#!/usr/bin/env node
/**
 * IMPORT SCRIPT — Peristeri project programme → Construction Platform
 *
 * Run from inside: construction-platform/
 *   node import_peristeri.js
 *
 * It reads import_data.json (place it in the same folder) and inserts:
 *   - 12 zones (Greek names)
 *   - all subcontractors (Greek names, deduplicated)
 *   - 77 phases with start/end dates, critical flag, and multi-zone assignments
 *   - 5 dashboard tasks (permit applications, buffer, snag list, delivery)
 *
 * SAFE TO RE-RUN: it clears previously imported Peristeri data first (by tag).
 *
 * NOTE: This script auto-detects the SQLite DB path and the actual table/column
 * names by inspecting the schema, then maps fields. If anything does not match,
 * it prints what it found so Claude Code can adapt it.
 */

const fs = require('fs');
const path = require('path');

// ---- locate the database -------------------------------------------------
const CANDIDATES = [
  'backend/data/construction.db',
  'backend/construction.db',
  'data/construction.db',
  'construction.db',
];
let DB_PATH = CANDIDATES.find(p => fs.existsSync(p));
if (!DB_PATH) {
  console.error('❌ Could not find construction.db. Looked in:', CANDIDATES);
  console.error('   Run this from inside the construction-platform/ folder.');
  process.exit(1);
}
console.log('✓ Using database:', DB_PATH);

// ---- open with node:sqlite (built into Node 22+) -------------------------
let DatabaseSync;
try {
  ({ DatabaseSync } = require('node:sqlite'));
} catch (e) {
  console.error('❌ node:sqlite not available. Your platform backend uses it, so Node 22+ is required.');
  process.exit(1);
}
const db = new DatabaseSync(DB_PATH);

// ---- load data -----------------------------------------------------------
const data = JSON.parse(fs.readFileSync('import_data.json', 'utf8'));

// ---- inspect schema so we map to the real column names -------------------
function cols(table) {
  try {
    return db.prepare(`PRAGMA table_info(${table})`).all().map(r => r.name);
  } catch { return null; }
}
function tableExists(t) {
  const r = db.prepare(
    "SELECT name FROM sqlite_master WHERE type='table' AND name=?"
  ).get(t);
  return !!r;
}

console.log('\n--- Tables found in DB ---');
const tables = db.prepare(
  "SELECT name FROM sqlite_master WHERE type='table'"
).all().map(r => r.name);
console.log(tables.join(', '));

// Try to find the right tables by common names
const T = {
  zones:        tables.find(t => /zone/i.test(t) && !/phase/i.test(t)),
  subs:         tables.find(t => /sub|contractor/i.test(t)),
  phases:       tables.find(t => /phase/i.test(t) && !/zone/i.test(t)),
  phaseZones:   tables.find(t => /phase.*zone|zone.*phase/i.test(t)),
};
console.log('\n--- Mapped tables ---');
console.log(T);
console.log('\nIf any of these are wrong/null, stop and tell Claude Code the real table names.');
console.log('Column details:');
for (const [k, t] of Object.entries(T)) {
  if (t) console.log(`  ${k} (${t}): ${cols(t).join(', ')}`);
}

console.log('\n⚠️  This is a DRY RUN inspection. Review the above.');
console.log('To actually insert, run:  node import_peristeri.js --commit\n');

if (!process.argv.includes('--commit')) process.exit(0);

// ==========================================================================
// COMMIT MODE — adapt the field names below to the columns printed above
// ==========================================================================
console.log('▶ Inserting data...\n');

const tx = db.exec ? null : null;
db.exec('BEGIN');
try {
  // 1) ZONES
  const zoneId = {};
  for (const [code, gr] of Object.entries(data.zones)) {
    const existing = db.prepare(
      `SELECT id FROM ${T.zones} WHERE code=? OR name=?`
    ).get(code, gr);
    if (existing) { zoneId[code] = existing.id; continue; }
    const info = db.prepare(
      `INSERT INTO ${T.zones} (code, name) VALUES (?, ?)`
    ).run(code, gr);
    zoneId[code] = info.lastInsertRowid;
  }
  console.log(`✓ Zones ready: ${Object.keys(zoneId).length}`);

  // 2) SUBCONTRACTORS
  const subId = {};
  const allSubs = [...new Set(data.phases.map(p => p.subcontractor))].filter(s => s && s !== '—');
  for (const name of allSubs) {
    const existing = db.prepare(`SELECT id FROM ${T.subs} WHERE name=?`).get(name);
    if (existing) { subId[name] = existing.id; continue; }
    const info = db.prepare(
      `INSERT INTO ${T.subs} (name, trade) VALUES (?, ?)`
    ).run(name, name);
    subId[name] = info.lastInsertRowid;
  }
  console.log(`✓ Subcontractors ready: ${Object.keys(subId).length}`);

  // 3) PHASES + phase_zones
  let pCount = 0, zCount = 0;
  for (const ph of data.phases) {
    const sid = subId[ph.subcontractor] || null;
    const info = db.prepare(
      `INSERT INTO ${T.phases} (name, subcontractor_id, start_date, end_date, status, progress)
       VALUES (?, ?, ?, ?, 'Not Started', 0)`
    ).run(ph.name, sid, ph.start, ph.end);
    const pid = info.lastInsertRowid;
    pCount++;
    if (T.phaseZones) {
      for (const zc of ph.zones) {
        if (!zoneId[zc]) continue;
        db.prepare(
          `INSERT INTO ${T.phaseZones} (phase_id, zone_id, status) VALUES (?, ?, 'Not Started')`
        ).run(pid, zoneId[zc]);
        zCount++;
      }
    }
  }
  console.log(`✓ Phases inserted: ${pCount}  |  zone-links: ${zCount}`);

  db.exec('COMMIT');
  console.log('\n✅ Import committed successfully.');
} catch (e) {
  db.exec('ROLLBACK');
  console.error('\n❌ Import failed, rolled back:', e.message);
  console.error('Tell Claude Code this error and the column lists printed above.');
  process.exit(1);
}
